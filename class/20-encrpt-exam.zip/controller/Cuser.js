const {User} = require('../models/index');

// 메인 페이지 이동
exports.index = (req, res)=>{
    res.render('index');
}

//회원 가입 처리
exports.register = async(req, res)=> {
    const { userid, pw, name} = req.body;
    try{
        await User.create({ userid, pw, name});
        res.json({result: true});
    }catch(err){
        console.error(err);
        res.status(500).send('Internal Server Error');
    }
}

//로그인 처리
exports.login = async(req, res)=>{
    const {userid, pw} = req.body;
    try{
        const user = await User.findOne({
            where: {userid}
        });
        if(user && user.pw ===pw){
            res.redirect('/profile');
        }else{
        res.status(401).send('로그인 실패!');
        }
    }catch(err){
        res.status(500).send('Internal Server Error');
    }
};